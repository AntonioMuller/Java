import java.util.Scanner;
public class ex_08 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
     int x;
     
	 x = 17;
	 System.out.println("a minha idade � "+ x);
	 x = sc.nextInt();
	 
	
		sc.close();
	}

}

