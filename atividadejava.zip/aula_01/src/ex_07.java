import java.util.Scanner;
public class ex_07 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
     String y;
     
	 y = "estou aprendendo java";
	 System.out.println("y significa: " + y);
	
	 
	
		sc.close();
	}

}

