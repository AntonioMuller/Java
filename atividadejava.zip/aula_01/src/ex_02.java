import java.util.Scanner;
public class ex_02 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

	 
	 System.out.println("� preciso fazer todos os algoritmos para aprender");
	
	 
	
		sc.close();
	}

}

