import java.util.Scanner;
public class ex_03 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

	 
	 System.out.println("Ant�nio M�ller Brugnago");
	
	 
	
		sc.close();
	}

}

