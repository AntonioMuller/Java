import java.util.Scanner;
public class ex_06 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
     int x;
     
	 x = 365;
	 System.out.println("o valor de x �: " + x);
	 x = sc.nextInt();
	 
	
		sc.close();
	}

}

