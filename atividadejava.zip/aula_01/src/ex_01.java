import java.util.Scanner;
public class ex_01 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

	 
	 System.out.println("Hello world!");
	
	 
	
		sc.close();
	}

}

