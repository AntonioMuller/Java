import java.util.Scanner;
public class ex_05 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
     int x;
     
	 x = (8+9+7)/3;
	 System.out.println("a m�dia aritm�tica de 8. 9 e 7 �: " + x);
	 x = sc.nextInt();
	 
	
		sc.close();
	}

}

