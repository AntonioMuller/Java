import java.util.Scanner;
public class ex_04 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	 int x;
	 
	 x = 48 * 23;
	 System.out.println("o produto de 28 e 43 �: " + x);
	 x = sc.nextInt();
	 


	
		sc.close();
	}

}

