import java.util.Scanner;

public class segundo {

	public static void main(String[] args) {
		Scanner sc = new Scanner (System.in);
		
		int gramas; 
		double preco = 0, imposto = 0, valorimposto = 0;
		System.out.println("Qual � o codigo do produto entre 1 e 10");
		int cod = sc.nextInt();
		System.out.println("Qual � o peso do produto?");
		int peso = sc.nextInt();
		System.out.println("Qual � do pa�s de origem do produto? entre 1 e 3");
		int codpais = sc.nextInt();
		
	
		if (cod >= 1 && cod <= 4) {
			gramas = peso * 1000;
			preco = gramas * 10;	
		}
		

		if (cod >= 5 && cod <= 7) {
			gramas = peso * 1000;
			preco = gramas * 25;
		}
		

		if (cod >= 8 && cod <= 10) {
			gramas = peso * 1000;
			preco = gramas * 35;
			
		}
		
		switch (codpais) {
		case 1:
			imposto = preco;
			valorimposto = imposto - preco;
			break;
		case 2: 
			imposto = preco * 1.15;
			valorimposto = imposto - preco;
			break;
		case 3: 
			imposto = preco * 1.25;
			valorimposto = imposto - preco;
			break;	
		}
		
		
		System.out.println("o peso do produto comprado � " +peso+ " o pre�o total do produto comprado �  "+preco+ " com imposto de " +valorimposto+ "e o pre�o total do produto mais imposto � "+imposto);
		
		sc.close();
		
		}
		
		
		
		

	}

